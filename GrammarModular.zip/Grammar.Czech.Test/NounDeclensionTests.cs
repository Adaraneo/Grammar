﻿namespace Grammar.Czech.Test
{
    [TestClass]
    public sealed class NounDeclensionTests
    {
        [TestMethod]
        public void NounDeclensions()
        {

        }
    }
}
